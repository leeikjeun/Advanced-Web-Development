var trandBtn = document.querySelector('.trand');
var issueBtn = document.querySelector('.issue');
var enterBtn = document.querySelector('.enter');

var lists = document.querySelector('#list');
var activeTmp = trandBtn;
var moreBtn = document.querySelector('.more-btn');

var urls = {
  trandingUrl : "http://1boon.kakao.com/ch/trending.json?pagesize=10&page=",
  issueUrl : "http://1boon.kakao.com/ch/issue.json?pagesize=10&page=",
  enterUrl : "http://1boon.kakao.com/ch/enter.json?pagesize=10&page=",
  trandingPage : 2,
  issuePage : 1,
  enterPage : 1
}

inputHtml(urls.trandingUrl + urls.trandingPage);

trandBtn.addEventListener('click', function(event){
  urls.trandingPage = 1;
  drowPage(urls.trandingUrl + urls.trandingPage, event);
  urls.trandingPage = 2;
});

issueBtn.addEventListener('click', function(event){
  urls.issuePage = 1;
  drowPage(urls.issueUrl + urls.issuePage ,event);
  urls.issuePage = 2;
});

enterBtn.addEventListener('click', function(event){
  urls.enterPage = 1;
  drowPage(urls.enterUrl + urls.enterPage , event);
  urls.enterPage = 2;
});

moreBtn.addEventListener('click',function(){
  if(activeTmp == trandBtn){
      inputHtml(urls.trandingUrl + urls.trandingPage);
      urls.trandingPage++;
  }else if(activeTmp == issueBtn){
      inputHtml(urls.issueUrl + urls.issuePage);
      urls.issuePage++;
  }else{
      inputHtml(urls.enterUrl + urls.enterPage);
      urls.enterPage++;
  }
});
